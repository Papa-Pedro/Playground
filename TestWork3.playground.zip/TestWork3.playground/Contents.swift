func bugFeatureChallenge(for value: Int) {
    for i in 1...value {
        if i % 3 == 0 { //проверка на кратность 3
            if i % 5 == 0 { //кратность 3 и 5 одновременно
                print("костыль")
            } else { //только 3
                print("баг")
            }
        } else {
            if i % 5 == 0 { //только 5 кратность
                print("фича")
            } else {
                print(i) //просто число
            }
        }
    }
}

bugFeatureChallenge(for: 20)
