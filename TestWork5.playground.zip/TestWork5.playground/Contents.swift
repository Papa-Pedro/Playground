import Foundation

func printSpiralMatrixWithSize(size: Int) {
    var yrArray = [Int]()
    for i in 0...size*size-1 { //заполнение массиву случайными числами
        yrArray.append(Int.random(in: 0..<10))
    }
    yrArray.sort()
    var prArray = [[Int]](repeating: [Int](repeating: 0, count: size), count: size)
    var l = 0, h = 0, index = 0, arSize = size
    while index < size*size {
        while h < arSize-1 { //заполнение по горизонтали сверху
            prArray[l][h] = yrArray[index]
            index += 1
            h += 1
        }
        while l < arSize-1 { //заполнение по вертикали справа
            prArray[l][h] = yrArray[index]
            index += 1
            l += 1
        }
        while h > (size - arSize) { //заполнение по горизонтали снизу
            prArray[l][h] = yrArray[index]
            index += 1
            h -= 1
        }
        while l > (size - arSize) { //заполнение по вертикали слева
            prArray[l][h] = yrArray[index]
            index += 1
            l -= 1
        }

        if (size*size - index) == 1 { //заполнение центра, если матрица не четного размера
            l = size / 2
            prArray[l][l] = yrArray[index]
            index += 1
        }
        arSize = arSize - 1 //уменьшение квадрата
        l = size - arSize
        h = size - arSize
   }
    //print(yrArray) для проверки исходного массива
    for index in 0...size-1 { //вывод
        print(prArray[index][0...size-1])
    }
}

printSpiralMatrixWithSize(size: 3)
