import Foundation

func fileNameFrom(path: String) -> String {
    let str = (path as NSString).lastPathComponent //оставляем последний компонент
    let newStr = str.index(of: ".") ?? str.endIndex //индекс точки в оставшимся компоненте
    let str3 = str[..<newStr] //создание нового компонента без расширения
    return String(str3) //для лучшего хранения переводим в стринг и выдаем на выходе
}

print(fileNameFrom(path: "C:/Program File/Data/Movies/BackToTheFuture3.avi"))
