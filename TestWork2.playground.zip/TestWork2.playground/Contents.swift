func reverseNumber(_ value: Double) -> Double {
    if (value.truncatingRemainder(dividingBy: 1) == 0) { //проверка число с дробной или нет частью
        if value >= 0 { //проверка на отицательность(положительность)
            return Double(Int(.init("\(Int(value))".reversed()))!) //переворот и передача на выход положительного(целого)
        }
        return -Double(Int(.init("\(Int(value * (-1) ))".reversed()))!) //отрицательного(целого)
    }
    else {
        if value >= 0 { //проверка числа на положительность(отрицательность)
            return Double(String((String(value)).reversed())) ?? 0.0 //положительного(вещественного)
        }
        return -(Double(String((String(value * (-1) )).reversed())) ?? 0.0) //отрицательного(вещественного)
    }
}

print(reverseNumber(-45.673))

